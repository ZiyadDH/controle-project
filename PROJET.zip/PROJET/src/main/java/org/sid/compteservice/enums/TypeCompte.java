package org.sid.compteservice.enums;

public enum TypeCompte {
    COURANT,
    EPARGNE
}
